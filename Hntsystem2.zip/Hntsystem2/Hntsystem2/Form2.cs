﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hntsystem2
{
    public partial class Form2 : Form
    {
        private int hintCount;

        public Form2(int hintCount)
        {
            InitializeComponent();
            this.hintCount = hintCount;
            UpdateHintCountLabel();

        }

        private void UpdateHintCountLabel()
        {
            hintLabel.Text = "Hints: " + hintCount.ToString();
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            
        }

        private void hintLabel_Click(object sender, EventArgs e)
        {
         
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var newform = new Form1();
            newform.Show();
            this.Hide();
            
        }

        private void HintButton_Click(object sender, EventArgs e)
        {
            {
                if (hintCount > 0)
                {
                    hintCount--;
                    HintImage.Visible = true;
                    HintButton.Visible = false;
                    hintLabel.Text = hintCount.ToString();
                    UpdateHintCountLabel();
                }
                else
                {
                    MessageBox.Show("Buy hints at store.");
                }

            }
        }
    }
}
