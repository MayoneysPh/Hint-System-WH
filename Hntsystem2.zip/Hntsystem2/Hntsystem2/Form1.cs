﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hntsystem2
{
    public partial class Form1 : Form
    {

        public static int hintCount = 0;
        public int amount = 5;

        public Form1()
        {
            InitializeComponent();
            UpdateHintCountLabel();

        }

        private void UpdateHintCountLabel()
        {
            hintLabel.Text = "Hints: " + hintCount.ToString();
        }
        private void HintButton_Click(object sender, EventArgs e)
        {
            if (hintCount > 0)
            {
                hintCount--;
                pctrBox.Visible = false;
                HintButton.Visible = false;
                UpdateHintCountLabel();
            }
            else
            {
                MessageBox.Show("Buy hint at store.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (hintCount < 50)
            {
                hintCount++;
                UpdateHintCountLabel();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (hintCount < 50)
            {
                hintCount += amount;
                UpdateHintCountLabel();
            }
        }


        private void hintCountLabel_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void hintLabel_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2(hintCount);
            frm.Show();
            
        }
    }
}
